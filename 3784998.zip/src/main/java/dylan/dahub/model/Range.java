package dylan.dahub.model;

public record Range(int lowerBound, int upperBound) {
}
