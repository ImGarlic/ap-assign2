package dylan.dahub.exception;

public class InvalidFileException extends Exception {
    public InvalidFileException(String reason) {
        super(reason);
    }

}
